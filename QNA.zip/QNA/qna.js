var x = document.getElementById("demo1").innerHTML;
function myFunction1(){
    document.getElementById("demo2").innerHTML = x + ("Neil Armstrong");
}


var y = document.getElementsByClassName("demo3").innerHTML;
function myFunction2(){
    document.getElementById("demo3").innerHTML = y + (" " + 1960);
}