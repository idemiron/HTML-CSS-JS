console.log('1')
console.log('2')

setTimeout(() =>{
    console.log('you are fired');
}, 5000);


console.log('3')